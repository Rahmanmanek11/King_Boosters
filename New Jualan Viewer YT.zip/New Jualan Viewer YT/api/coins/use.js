// api/coins/use.js
import fs from 'fs';
import path from 'path';

export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, error: 'No token provided' });
    }

    const token = authHeader.substring(7);
    const { userId, amount, campaignId } = req.body;

    if (!userId || !amount || amount <= 0) {
      return res.status(400).json({ success: false, error: 'Invalid request' });
    }

    const usersPath = path.join(process.cwd(), 'data', 'users.json');
    if (!fs.existsSync(usersPath)) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    let users = JSON.parse(fs.readFileSync(usersPath, 'utf8') || '[]');
    const userIndex = users.findIndex(u => u.id === userId && u.token === token);

    if (userIndex === -1) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    // Cek koin cukup
    if ((users[userIndex].coins || 0) < amount) {
      return res.status(400).json({ success: false, error: 'Insufficient coins' });
    }

    // Kurangi koin
    users[userIndex].coins -= amount;
    users[userIndex].totalSpent = (users[userIndex].totalSpent || 0) + amount;
    
    // Tambah history
    if (!users[userIndex].coinHistory) users[userIndex].coinHistory = [];
    users[userIndex].coinHistory.unshift({
      date: new Date().toISOString().split('T')[0],
      type: 'spend',
      amount: amount,
      description: campaignId ? `Campaign #${campaignId}` : 'Penggunaan koin'
    });

    fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));

    res.json({
      success: true,
      newBalance: users[userIndex].coins
    });
  } catch (error) {
    console.error('Use coins error:', error);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
}