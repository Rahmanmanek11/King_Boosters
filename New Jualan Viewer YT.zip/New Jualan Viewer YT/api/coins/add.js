// api/coins/add.js
import fs from 'fs';
import path from 'path';

export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const { userId, amount, description } = req.body;

    if (!userId || !amount || amount <= 0) {
      return res.status(400).json({ success: false, error: 'Invalid request' });
    }

    const usersPath = path.join(process.cwd(), 'data', 'users.json');
    if (!fs.existsSync(usersPath)) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    let users = JSON.parse(fs.readFileSync(usersPath, 'utf8') || '[]');
    const userIndex = users.findIndex(u => u.id === userId);

    if (userIndex === -1) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    // Tambah koin
    users[userIndex].coins = (users[userIndex].coins || 0) + amount;
    users[userIndex].totalEarned = (users[userIndex].totalEarned || 0) + amount;
    
    // Tambah history
    if (!users[userIndex].coinHistory) users[userIndex].coinHistory = [];
    users[userIndex].coinHistory.unshift({
      date: new Date().toISOString().split('T')[0],
      type: 'earn',
      amount: amount,
      description: description || 'Penambahan koin'
    });

    fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));

    res.json({
      success: true,
      newBalance: users[userIndex].coins,
      message: 'Koin berhasil ditambahkan'
    });
  } catch (error) {
    console.error('Add coins error:', error);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
}