// api/campaign/progress.js
import fs from 'fs';
import path from 'path';

export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const { videoId, userId } = req.body;

    if (!videoId) {
      return res.status(400).json({ success: false, error: 'Video ID required' });
    }

    const usersPath = path.join(process.cwd(), 'data', 'users.json');
    if (!fs.existsSync(usersPath)) {
      return res.status(404).json({ success: false, error: 'Data not found' });
    }

    let users = JSON.parse(fs.readFileSync(usersPath, 'utf8') || '[]');
    let updated = false;

    // Update semua campaign dengan videoId yang sama
    for (let i = 0; i < users.length; i++) {
      if (users[i].campaigns) {
        for (let j = 0; j < users[i].campaigns.length; j++) {
          if (users[i].campaigns[j].videoId === videoId && 
              users[i].campaigns[j].status === 'active') {
            
            users[i].campaigns[j].current += 1;
            users[i].campaigns[j].lastView = new Date().toISOString();
            
            // Cek apakah sudah mencapai target
            if (users[i].campaigns[j].current >= users[i].campaigns[j].target) {
              users[i].campaigns[j].status = 'completed';
            }
            
            updated = true;
          }
        }
      }
    }

    if (updated) {
      fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));
    }

    res.json({
      success: true,
      updated
    });
  } catch (error) {
    console.error('Update progress error:', error);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
}