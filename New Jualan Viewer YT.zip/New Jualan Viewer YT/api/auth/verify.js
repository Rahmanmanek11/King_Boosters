// api/auth/verify.js
import fs from 'fs';
import path from 'path';

export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, error: 'No token provided' });
    }

    const token = authHeader.substring(7);

    // Baca file users.json
    const usersPath = path.join(process.cwd(), 'data', 'users.json');
    if (!fs.existsSync(usersPath)) {
      return res.status(401).json({ success: false, error: 'Invalid token' });
    }

    const users = JSON.parse(fs.readFileSync(usersPath, 'utf8') || '[]');
    
    // Cari user dengan token yang sama
    const user = users.find(u => u.token === token);

    if (!user) {
      return res.status(401).json({ success: false, error: 'Invalid token' });
    }

    // Kirim data user
    res.json({
      success: true,
      valid: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        username: user.username,
        coins: user.coins || 0,
        package: user.package || 'free',
        channels: user.channels || []
      }
    });
  } catch (error) {
    console.error('Verify error:', error);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
}