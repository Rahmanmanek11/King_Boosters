// api/auth/register.js
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export const config = {
  api: {
    bodyParser: true,
  },
};

export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const { name, email, username, password, whatsapp, initialPackage } = req.body;

    // Validasi
    if (!name || !email || !username || !password || !whatsapp) {
      return res.status(400).json({ success: false, error: 'Semua field harus diisi' });
    }

    if (password.length < 6) {
      return res.status(400).json({ success: false, error: 'Password minimal 6 karakter' });
    }

    // Validasi email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ success: false, error: 'Email tidak valid' });
    }

    // Validasi whatsapp
    const waRegex = /^62\d{9,12}$/;
    if (!waRegex.test(whatsapp)) {
      return res.status(400).json({ success: false, error: 'Nomor WhatsApp harus format 62xxx (contoh: 628123456789)' });
    }

    // Baca file users.json
    const usersPath = path.join(process.cwd(), 'data', 'users.json');
    let users = [];

    try {
      const dataDir = path.join(process.cwd(), 'data');
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      if (fs.existsSync(usersPath)) {
        const fileContent = fs.readFileSync(usersPath, 'utf8');
        users = fileContent ? JSON.parse(fileContent) : [];
      }
    } catch (error) {
      console.error('Error reading users file:', error);
      return res.status(500).json({ success: false, error: 'Server error' });
    }

    // Cek duplikat
    if (users.find(u => u.email === email)) {
      return res.status(400).json({ success: false, error: 'Email sudah terdaftar' });
    }

    if (users.find(u => u.username === username)) {
      return res.status(400).json({ success: false, error: 'Username sudah digunakan' });
    }

    if (users.find(u => u.whatsapp === whatsapp)) {
      return res.status(400).json({ success: false, error: 'Nomor WhatsApp sudah terdaftar' });
    }

    // Tentukan koin awal berdasarkan paket
    let initialCoins = 0;
    let package = 'free';

    if (initialPackage === 'basic') {
      initialCoins = 500;
      package = 'basic';
    } else if (initialPackage === 'pro') {
      initialCoins = 1200;
      package = 'pro';
    } else if (initialPackage === 'legends') {
      initialCoins = 2500;
      package = 'legends';
    }

    // Hash password
    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

    // Buat user baru
    const newUser = {
      id: crypto.randomUUID(),
      name,
      email,
      username,
      password: hashedPassword,
      whatsapp,
      package,
      coins: initialCoins,
      channels: [],
      campaigns: [],
      coinHistory: initialCoins > 0 ? [{
        date: new Date().toISOString().split('T')[0],
        type: 'purchase',
        amount: initialCoins,
        description: `Pembelian paket ${package}`
      }] : [],
      totalEarned: 0,
      totalSpent: 0,
      createdAt: new Date().toISOString(),
      lastLogin: null
    };

    users.push(newUser);

    // Simpan ke file
    try {
      fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));
    } catch (error) {
      console.error('Error saving user:', error);
      return res.status(500).json({ success: false, error: 'Gagal menyimpan data' });
    }

    res.json({
      success: true,
      message: 'Registrasi berhasil',
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        username: newUser.username
      }
    });
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
}