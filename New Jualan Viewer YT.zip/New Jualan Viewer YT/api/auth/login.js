// api/auth/login.js
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export const config = {
  api: {
    bodyParser: true,
  },
};

export default function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, error: 'Email dan password harus diisi' });
    }

    // Baca file users.json
    const usersPath = path.join(process.cwd(), 'data', 'users.json');
    let users = [];

    try {
      if (fs.existsSync(usersPath)) {
        const fileContent = fs.readFileSync(usersPath, 'utf8');
        users = fileContent ? JSON.parse(fileContent) : [];
      } else {
        // Buat folder data jika belum ada
        const dataDir = path.join(process.cwd(), 'data');
        if (!fs.existsSync(dataDir)) {
          fs.mkdirSync(dataDir, { recursive: true });
        }
        // Buat file users.json kosong
        fs.writeFileSync(usersPath, JSON.stringify([]));
      }
    } catch (error) {
      console.error('Error reading users file:', error);
      return res.status(500).json({ success: false, error: 'Server error' });
    }

    // Hash password untuk perbandingan (dalam production gunakan bcrypt)
    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

    // Cari user
    const user = users.find(u => u.email === email && u.password === hashedPassword);

    if (!user) {
      return res.status(401).json({ success: false, error: 'Email atau password salah' });
    }

    // Generate token sederhana (dalam production gunakan JWT)
    const token = crypto
      .createHash('sha256')
      .update(`${user.id}-${Date.now()}-${Math.random()}`)
      .digest('hex');

    // Simpan token ke user (optional)
    user.lastLogin = new Date().toISOString();
    user.token = token;

    // Update users file
    try {
      fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));
    } catch (error) {
      console.error('Error saving user token:', error);
    }

    // Kirim response tanpa password
    const userResponse = {
      id: user.id,
      name: user.name,
      email: user.email,
      username: user.username,
      whatsapp: user.whatsapp,
      coins: user.coins || 0,
      package: user.package || 'free',
      channels: user.channels || [],
      campaigns: user.campaigns || [],
      coinHistory: user.coinHistory || [],
      createdAt: user.createdAt
    };

    res.json({
      success: true,
      user: userResponse,
      token
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
}