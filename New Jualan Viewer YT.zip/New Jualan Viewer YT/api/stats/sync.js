// api/stats/sync.js
import fs from 'fs';
import path from 'path';

export default function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, error: 'No token provided' });
    }

    const token = authHeader.substring(7);
    const { userId, sessions, viewers, timestamp } = req.body;

    if (!userId) {
      return res.status(400).json({ success: false, error: 'User ID required' });
    }

    const usersPath = path.join(process.cwd(), 'data', 'users.json');
    if (!fs.existsSync(usersPath)) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    let users = JSON.parse(fs.readFileSync(usersPath, 'utf8') || '[]');
    const userIndex = users.findIndex(u => u.id === userId && u.token === token);

    if (userIndex === -1) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }

    // Update stats (bisa ditambahkan field stats jika perlu)
    if (!users[userIndex].stats) users[userIndex].stats = {};
    users[userIndex].stats.lastSync = timestamp;
    users[userIndex].stats.totalSessions = sessions;
    users[userIndex].stats.totalViewers = viewers;

    fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));

    res.json({
      success: true,
      message: 'Stats synced'
    });
  } catch (error) {
    console.error('Sync error:', error);
    res.status(500).json({ success: false, error: 'Internal server error' });
  }
}