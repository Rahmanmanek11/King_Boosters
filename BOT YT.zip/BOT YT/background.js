// Bot Youtube Rahman - Background Service Worker
let isRunning = false;
let settings = null;
let activeTabs = [];
let sessionsCompleted = 0;
let currentMode = '-';
let wipeEnabled = true;
let failedTabs = 0;
let successTabs = 0;
let currentViewers = 0;
let targetViewers = 100;
let singleTabMode = true;

// Initialize
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ 
    sessionsCompleted: 0,
    isRunning: false,
    failedTabs: 0,
    successTabs: 0,
    currentViewers: 0,
    targetViewers: 100
  });
});

// Message handler
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.action) {
    case 'startBot':
      startBot(request.settings);
      sendResponse({ success: true, message: `Starting with target ${request.settings.targetViewers} viewers` });
      break;
      
    case 'stopBot':
      stopBot();
      sendResponse({ success: true });
      break;
      
    case 'clearBrowsingData':
      clearBrowsingData().then(() => sendResponse({ success: true }));
      return true;
      
    case 'getStats':
      chrome.storage.local.get([
        'sessionsCompleted', 'isRunning', 'failedTabs', 
        'successTabs', 'currentViewers', 'targetViewers'
      ], (data) => {
        sendResponse({
          running: isRunning || data.isRunning || false,
          sessions: data.sessionsCompleted || 0,
          activeTabs: activeTabs.length,
          currentMode: currentMode,
          failedTabs: data.failedTabs || 0,
          successTabs: data.successTabs || 0,
          currentViewers: data.currentViewers || 0,
          targetViewers: data.targetViewers || 0
        });
      });
      return true;
      
    case 'sessionComplete':
      sessionsCompleted++;
      successTabs++;
      currentViewers++;
      
      chrome.storage.local.set({ 
        sessionsCompleted,
        successTabs,
        currentViewers
      });
      
      console.log(`Session complete! Total viewers: ${currentViewers}/${targetViewers}`);
      
      // Check if target reached
      if (targetViewers > 0 && currentViewers >= targetViewers) {
        console.log('🎯 Target viewers reached! Stopping all bots...');
        stopBot();
        // Cek apakah notifikasi tersedia
        if (chrome.notifications) {
          try {
            chrome.notifications.create({
              type: 'basic',
              iconUrl: 'icons/icon128.png',
              title: 'Target Viewer Tercapai!',
              message: `✅ ${currentViewers} viewers telah ditonton`,
              priority: 2
            });
          } catch (e) {
            console.log('Notifikasi tidak tersedia:', e);
          }
        }
        sendResponse({ success: true });
        return;
      }
      
      // Close the tab that just completed
      if (request.tabId) {
        console.log('Closing tab:', request.tabId);
        chrome.tabs.remove(request.tabId).catch(() => {});
        activeTabs = activeTabs.filter(id => id !== request.tabId);
      }
      
      // Schedule new tab if still running and single tab mode
      if (isRunning && settings) {
        if (singleTabMode) {
          // Single tab mode - buka tab baru setelah yang lama ditutup
          setTimeout(() => {
            if (isRunning) {
              createNewTab();
            }
          }, getRandomInt(settings.delayMin, settings.delayMax) * 1000);
        } else {
          // Multi tab mode - buka sesuai jumlah tab
          scheduleNewTab();
        }
      }
      
      if (wipeEnabled && isRunning) {
        scheduleWipe();
      }
      
      sendResponse({ success: true });
      break;
      
    case 'tabOpened':
      if (!activeTabs.includes(request.tabId)) {
        activeTabs.push(request.tabId);
      }
      sendResponse({ success: true });
      break;
      
    case 'tabError':
      console.error('Tab error:', request.error);
      failedTabs++;
      chrome.storage.local.set({ failedTabs });
      
      if (request.tabId) {
        // Close error tab
        chrome.tabs.remove(request.tabId).catch(() => {});
        activeTabs = activeTabs.filter(id => id !== request.tabId);
      }
      
      // Schedule replacement tab if still running
      if (isRunning && settings) {
        setTimeout(() => {
          if (isRunning) {
            if (singleTabMode) {
              createNewTab();
            } else {
              scheduleNewTab();
            }
          }
        }, 5000);
      }
      
      sendResponse({ success: true });
      break;
      
    case 'updateViewers':
      currentViewers = request.count || currentViewers;
      chrome.storage.local.set({ currentViewers });
      sendResponse({ success: true });
      break;
  }
});

// Tab removal listener
chrome.tabs.onRemoved.addListener((tabId) => {
  activeTabs = activeTabs.filter(id => id !== tabId);
});

// Tab update listener
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('youtube.com')) {
    // Check for error pages
    if (tab.url.includes('error') || tab.url.includes('404')) {
      chrome.tabs.sendMessage(tabId, { action: 'checkError' }).catch(() => {});
    }
  }
});

async function startBot(botSettings) {
  // Validate settings
  if (!botSettings) {
    console.error('No settings provided');
    return;
  }
  
  // Stop any running bot
  if (isRunning) {
    await stopBot();
  }
  
  settings = botSettings;
  isRunning = true;
  currentMode = settings.mode === 'search' ? 'Search' : 'Rekomendasi';
  wipeEnabled = settings.autoWipe;
  targetViewers = settings.targetViewers || 100;
  singleTabMode = settings.singleTab !== undefined ? settings.singleTab : true;
  
  // Reset counters
  sessionsCompleted = 0;
  successTabs = 0;
  failedTabs = 0;
  currentViewers = 0;
  
  chrome.storage.local.set({ 
    isRunning: true, 
    currentMode,
    failedTabs: 0,
    successTabs: 0,
    currentViewers: 0,
    targetViewers
  });
  
  console.log(`Bot started with target: ${targetViewers} viewers, Single Tab Mode: ${singleTabMode}`);
  
  // Start with one tab
  createNewTab();
  
  // Show notification if available
  if (chrome.notifications) {
    try {
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'Bot Dimulai',
        message: `Target: ${targetViewers} viewers`,
        priority: 2
      });
    } catch (e) {
      console.log('Notifikasi tidak tersedia');
    }
  }
}

async function stopBot() {
  isRunning = false;
  currentMode = '-';
  
  // Close all active tabs
  for (const tabId of activeTabs) {
    try {
      await chrome.tabs.remove(tabId);
    } catch (e) {
      // Ignore errors
    }
  }
  
  activeTabs = [];
  chrome.storage.local.set({ 
    isRunning: false, 
    currentMode: '-',
    currentViewers: 0
  });
  
  console.log('Bot stopped');
}

function createNewTab() {
  if (!isRunning) return;
  
  chrome.tabs.create({ 
    url: 'https://www.youtube.com',
    active: false 
  }, (tab) => {
    if (chrome.runtime.lastError) {
      console.error('Failed to create tab:', chrome.runtime.lastError);
      return;
    }
    
    activeTabs.push(tab.id);
    console.log(`New tab created: ${tab.id}, Active tabs: ${activeTabs.length}`);
    
    // Wait for page to load
    chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        
        // Send settings to content script
        setTimeout(() => {
          chrome.tabs.sendMessage(tab.id, { 
            action: 'startSession', 
            settings: settings,
            tabId: tab.id,
            targetViewers: targetViewers,
            currentViewers: currentViewers
          }).catch((error) => {
            // Content script might not be ready, try to inject
            chrome.scripting.executeScript({
              target: { tabId: tab.id },
              files: ['content.js']
            }).then(() => {
              setTimeout(() => {
                chrome.tabs.sendMessage(tab.id, { 
                  action: 'startSession', 
                  settings: settings,
                  tabId: tab.id
                }).catch(e => console.log('Still failed:', e));
              }, 1000);
            }).catch(e => console.log('Injection failed:', e));
          });
        }, 2000);
      }
    });
  });
}

function scheduleNewTab() {
  if (!isRunning) return;
  
  const delay = getRandomInt(settings.delayMin, settings.delayMax) * 1000;
  
  setTimeout(() => {
    if (isRunning && activeTabs.length < settings.tabCount) {
      createNewTab();
    }
  }, delay);
}

async function clearBrowsingData() {
  return new Promise((resolve) => {
    const options = {
      since: 0
    };
    
    const dataTypes = {
      history: true,
      cache: true,
      cookies: false,
      localStorage: true
    };
    
    chrome.browsingData.remove(options, dataTypes, () => {
      console.log('Browsing data cleared (excluding cookies)');
      resolve();
    });
  });
}

function scheduleWipe() {
  setTimeout(() => {
    if (isRunning) {
      clearBrowsingData();
    }
  }, getRandomInt(3000, 7000));
}

// Hapus fungsi showNotification yang bermasalah

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}