// Bot Youtube Rahman - Content Script
let botActive = false;
let settings = null;
let currentPhase = 'idle';
let currentVideoId = null;
let mousePointer = null;
let pointerVisible = false;
let videoPlayer = null;
let sessionTabId = null;
let hudElement = null;
let watchTimer = null;
let scrollInterval = null;
let mouseMoveInterval = null;
let errorCount = 0;
let typingInterval = null;
let currentWatchTime = 0;
let totalWatchTime = 0;
let targetViewers = 100;
let currentViewers = 0;
let mouseX = 0;
let mouseY = 0;
let hudCheckInterval = null;
let timerInterval = null;
let isWatching = false;
let watchStartTime = null;
let watchElapsed = 0;
let forceHUDVisible = false;
let currentVideoType = 'channel';
let currentTargetIndex = 0;
let channelVideos = [];
let overlayElement = null;
let videoProgressListener = null;
let lastVideoTime = 0;
let speedChangeListener = null;
let overlayCheckInterval = null;
let navigationInProgress = false;
const MAX_ERRORS = 5;

// Statistics
let stats = {
  sessionsCompleted: 0,
  channelVideosWatched: 0,
  targetVideosWatched: 0,
  errors: 0
};

const CHANNEL_URL = 'https://www.youtube.com/@tripoint-t6z';

window.addEventListener('load', () => {
  initializeBot();
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'startSession') {
    settings = request.settings;
    botActive = true;
    sessionTabId = sender?.tab?.id || request.tabId;
    targetViewers = request.targetViewers || settings.targetViewers || 100;
    currentViewers = request.currentViewers || 0;
    errorCount = 0;
    currentPhase = 'idle';
    isWatching = false;
    watchElapsed = 0;
    forceHUDVisible = true;
    currentVideoType = request.videoType || 'channel';
    
    chrome.storage.local.get(['botStats'], (data) => {
      if (data.botStats) {
        stats = data.botStats;
      }
    });
    
    // Buat overlay transparan untuk mencegah interaksi
    createProtectiveOverlay();
    
    if (settings.showHud) {
      setTimeout(() => {
        createHUD();
        startHUDCheck();
        startTimerUpdate(); // PASTIKAN TIMER JALAN
      }, 500);
    }
    
    if (settings.showPointer) {
      createMousePointer();
      showMousePointer();
    }
    
    setTimeout(() => {
      if (currentVideoType === 'channel') {
        findRandomChannelVideo();
      } else {
        prepareSearchBox();
        setTimeout(() => startSearchMode(), 2000);
      }
    }, 3000);
    
    sendResponse({ success: true });
  }
  
  if (request.action === 'stopBot') {
    stopBot();
    sendResponse({ success: true });
  }
  
  if (request.action === 'updateHUD') {
    updateHUD(request.data);
    sendResponse({ success: true });
  }
});

// Fungsi untuk membuat overlay transparan yang mencegah interaksi
function createProtectiveOverlay() {
  // Hapus overlay lama jika ada
  const oldOverlay = document.getElementById('bot-protective-overlay');
  if (oldOverlay) oldOverlay.remove();
  
  overlayElement = document.createElement('div');
  overlayElement.id = 'bot-protective-overlay';
  overlayElement.style.cssText = `
    position: fixed !important;
    top: 0 !important;
    left: 0 !important;
    width: 100% !important;
    height: 100% !important;
    background: transparent !important;
    z-index: 999999998 !important;
    pointer-events: all !important;
    cursor: not-allowed !important;
    display: block !important;
  `;
  
  // Tambahkan event listener untuk mencegah semua interaksi
  const blockEvent = (e) => {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    return false;
  };
  
  overlayElement.addEventListener('click', blockEvent, true);
  overlayElement.addEventListener('mousedown', blockEvent, true);
  overlayElement.addEventListener('mouseup', blockEvent, true);
  overlayElement.addEventListener('mousemove', blockEvent, true);
  overlayElement.addEventListener('mouseover', blockEvent, true);
  overlayElement.addEventListener('mouseout', blockEvent, true);
  overlayElement.addEventListener('keydown', blockEvent, true);
  overlayElement.addEventListener('keyup', blockEvent, true);
  overlayElement.addEventListener('keypress', blockEvent, true);
  overlayElement.addEventListener('wheel', blockEvent, true);
  overlayElement.addEventListener('touchstart', blockEvent, true);
  overlayElement.addEventListener('touchend', blockEvent, true);
  overlayElement.addEventListener('touchmove', blockEvent, true);
  
  document.body.appendChild(overlayElement);
  console.log('✅ Protective overlay created');
  
  // Mulai monitoring overlay
  startOverlayMonitoring();
}

function startOverlayMonitoring() {
  if (overlayCheckInterval) clearInterval(overlayCheckInterval);
  
  overlayCheckInterval = setInterval(() => {
    if (!botActive) return;
    
    const existingOverlay = document.getElementById('bot-protective-overlay');
    if (!existingOverlay) {
      console.log('⚠️ Overlay hilang, membuat ulang...');
      createProtectiveOverlay();
    }
  }, 500);
}

function removeProtectiveOverlay() {
  if (overlayElement) {
    overlayElement.remove();
    overlayElement = null;
  }
  if (overlayCheckInterval) {
    clearInterval(overlayCheckInterval);
    overlayCheckInterval = null;
  }
}

function startHUDCheck() {
  if (hudCheckInterval) clearInterval(hudCheckInterval);
  
  hudCheckInterval = setInterval(() => {
    if (!botActive) return;
    
    // Cek HUD
    if (settings?.showHud) {
      const existingHUD = document.getElementById('bot-youtube-rahman-hud');
      if (!existingHUD || existingHUD.style.display === 'none' || existingHUD.offsetParent === null) {
        console.log('⚠️ HUD hilang, membuat ulang...');
        createHUD();
      }
    }
    
    // Cek overlay
    if (botActive) {
      const existingOverlay = document.getElementById('bot-protective-overlay');
      if (!existingOverlay) {
        console.log('⚠️ Overlay hilang, membuat ulang...');
        createProtectiveOverlay();
      }
    }
  }, 500);
}

function initializeBot() {
  // CEK APAKAH INI HASIL NAVIGASI DARI BOT
  if (sessionStorage.getItem('botActive') === 'true') {
    console.log('🔄 Restore state setelah navigasi ke halaman video...');
    
    // RESTORE SEMUA STATE
    botActive = true;
    try {
      settings = JSON.parse(sessionStorage.getItem('botSettings'));
      stats = JSON.parse(sessionStorage.getItem('botStats'));
    } catch (e) {
      console.error('Gagal parse sessionStorage', e);
    }
    
    currentViewers = parseInt(sessionStorage.getItem('botCurrentViewers')) || 0;
    targetViewers = parseInt(sessionStorage.getItem('botTargetViewers')) || 100;
    currentPhase = sessionStorage.getItem('botPhase') || 'watching';
    pointerVisible = sessionStorage.getItem('botPointerVisible') === 'true';
    sessionTabId = parseInt(sessionStorage.getItem('botSessionTabId')) || null;
    
    const showHud = sessionStorage.getItem('botShowHud') === 'true';
    const showPointer = sessionStorage.getItem('botShowPointer') === 'true';
    
    // HAPUS SESSION STORAGE
    sessionStorage.clear();
    
    // BUAT ULANG OVERLAY DAN HUD SETELAH HALAMAN LOAD
    setTimeout(() => {
      console.log('Membuat ulang overlay dan HUD setelah navigasi...');
      
      // Buat overlay protektif
      if (!document.getElementById('bot-protective-overlay')) {
        createProtectiveOverlay();
      }
      
      // Buat HUD
      if (showHud) {
        if (!document.getElementById('bot-youtube-rahman-hud')) {
          createHUD();
          startHUDCheck();
          startTimerUpdate(); // PASTIKAN TIMER JALAN
        }
      }
      
      // Buat mouse pointer
      if (showPointer) {
        if (!document.getElementById('bot-mouse-pointer')) {
          createMousePointer();
          showMousePointer();
        }
      }
      
      // MULAI LAGI PROSES MENONTON SESUAI PHASE
      if (currentPhase === 'watching') {
        console.log('Melanjutkan proses menonton channel...');
        setTimeout(() => startWatchingChannelVideo(), 3000);
      } else if (currentPhase === 'target') {
        console.log('Melanjutkan proses menonton target...');
        setTimeout(() => startWatchingTargetVideo(), 3000);
      }
    }, 2000);
  }
  
  checkForErrors();
  
  const observer = new MutationObserver(() => {
    checkForErrors();
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

function prepareSearchBox() {
  const searchSelectors = [
    'input#search',
    'input[name="search_query"]',
    'ytd-searchbox input',
    '#search-input input',
    'input#search-input',
    '#search-form input'
  ];
  
  for (const selector of searchSelectors) {
    const box = document.querySelector(selector);
    if (box) {
      console.log('Search box ditemukan dengan selector:', selector);
      return true;
    }
  }
  
  setTimeout(prepareSearchBox, 1000);
  return false;
}

function checkForErrors() {
  const errorSelectors = [
    '.yt-error-message',
    '#error-screen',
    '.yt-player-error-message-renderer',
    '.yt-playability-error-supported-renderers',
    '#error-page',
    '.ytcp-error'
  ];
  
  for (const selector of errorSelectors) {
    const errorEl = document.querySelector(selector);
    if (errorEl && errorEl.offsetParent !== null) {
      const isVisible = errorEl.offsetWidth > 0 || errorEl.offsetHeight > 0;
      if (isVisible) {
        handleError('Detected error page');
        return;
      }
    }
  }
  
  const unavailableText = document.body.innerText;
  const errorKeywords = [
    'Video tidak tersedia',
    'Video unavailable',
    'This video is unavailable',
    'Playback error',
    'Terjadi kesalahan',
    'Tidak dapat memutar'
  ];
  
  for (const keyword of errorKeywords) {
    if (unavailableText.includes(keyword)) {
      handleError(`Error: ${keyword}`);
      return;
    }
  }
}

function handleError(errorMsg) {
  console.error('Bot Error:', errorMsg);
  errorCount++;
  stats.errors++;
  
  showErrorToast(errorMsg);
  
  saveStats();
  updateHUDStats();
  
  chrome.runtime.sendMessage({
    action: 'tabError',
    error: errorMsg,
    tabId: sessionTabId
  });
  
  if (errorCount >= MAX_ERRORS) {
    stopBot();
  } else {
    recoverFromError();
  }
}

function showErrorToast(message) {
  const toast = document.createElement('div');
  toast.className = 'bot-error-toast';
  toast.textContent = `⚠️ ${message}`;
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, 3000);
}

function recoverFromError() {
  window.location.href = 'https://www.youtube.com';
  
  setTimeout(() => {
    if (botActive) {
      if (currentVideoType === 'channel') {
        findRandomChannelVideo();
      } else {
        prepareSearchBox();
        setTimeout(() => startSearchMode(), 3000);
      }
    }
  }, 5000);
}

function createMousePointer() {
  const oldPointer = document.getElementById('bot-mouse-pointer');
  if (oldPointer) oldPointer.remove();
  
  const pointer = document.createElement('div');
  pointer.id = 'bot-mouse-pointer';
  
  pointer.innerHTML = `
    <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M2 2L10 22L13 13L22 10L2 2Z" fill="#ff0000" stroke="#ffffff" stroke-width="2"/>
      <circle cx="13" cy="13" r="5" fill="#ffffff" fill-opacity="0.7"/>
    </svg>
  `;
  
  pointer.style.cssText = `
    position: fixed !important;
    width: 28px !important;
    height: 28px !important;
    pointer-events: none !important;
    z-index: 1000000000 !important;
    filter: drop-shadow(3px 3px 5px rgba(0,0,0,0.8)) !important;
    transition: transform 0.05s linear !important;
    will-change: transform !important;
    display: none;
  `;
  
  document.body.appendChild(pointer);
  mousePointer = pointer;
  
  document.addEventListener('mousemove', (e) => {
    if (pointerVisible && mousePointer) {
      mouseX = e.clientX;
      mouseY = e.clientY;
      updatePointerPosition();
    }
  });
}

function updatePointerPosition() {
  if (!mousePointer || !pointerVisible) return;
  mousePointer.style.transform = `translate(${mouseX - 2}px, ${mouseY - 2}px)`;
}

function showMousePointer() {
  if (mousePointer && settings.showPointer) {
    mousePointer.style.display = 'block';
    pointerVisible = true;
    mouseX = window.innerWidth / 2;
    mouseY = window.innerHeight / 2;
    updatePointerPosition();
    startRandomMouseMovement();
  }
}

function hideMousePointer() {
  if (mousePointer) {
    mousePointer.style.display = 'none';
    pointerVisible = false;
    if (mouseMoveInterval) {
      clearInterval(mouseMoveInterval);
      mouseMoveInterval = null;
    }
  }
}

function startRandomMouseMovement() {
  if (mouseMoveInterval) clearInterval(mouseMoveInterval);
  
  const moveRandomly = () => {
    if (!pointerVisible || !botActive) return;
    
    let moveX = (Math.random() - 0.5) * 300;
    let moveY = (Math.random() - 0.5) * 200;
    
    let newX = mouseX + moveX;
    let newY = mouseY + moveY;
    
    newX = Math.max(10, Math.min(window.innerWidth - 10, newX));
    newY = Math.max(10, Math.min(window.innerHeight - 10, newY));
    
    animateMouseMove(newX, newY);
  };
  
  mouseMoveInterval = setInterval(moveRandomly, getRandomInt(3000, 6000));
}

function animateMouseMove(targetX, targetY) {
  if (!pointerVisible) return;
  
  const startX = mouseX;
  const startY = mouseY;
  const startTime = performance.now();
  const duration = 800;
  
  function animate(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const easeProgress = 1 - Math.pow(1 - progress, 3);
    
    mouseX = startX + (targetX - startX) * easeProgress;
    mouseY = startY + (targetY - startY) * easeProgress;
    
    updatePointerPosition();
    
    if (progress < 1) {
      requestAnimationFrame(animate);
    }
  }
  
  requestAnimationFrame(animate);
}

async function moveMouseToElement(element) {
  if (!element || !pointerVisible || !mousePointer) return;
  
  const rect = element.getBoundingClientRect();
  const targetX = rect.left + (rect.width / 2);
  const targetY = rect.top + (rect.height / 2);
  
  return new Promise((resolve) => {
    const startX = mouseX;
    const startY = mouseY;
    const startTime = performance.now();
    const duration = 1000;
    
    function animate(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      
      mouseX = startX + (targetX - startX) * easeProgress;
      mouseY = startY + (targetY - startY) * easeProgress;
      
      updatePointerPosition();
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setTimeout(resolve, 300);
      }
    }
    
    requestAnimationFrame(animate);
  });
}

// ============ FUNGSI CREATE HUD ============
function createHUD() {
  console.log('MEMBUAT HUD BARU...');
  
  const oldHUD = document.getElementById('bot-youtube-rahman-hud');
  if (oldHUD) oldHUD.remove();
  
  hudElement = document.createElement('div');
  hudElement.id = 'bot-youtube-rahman-hud';
  
  const phaseText = currentPhase === 'channel' ? 'CHANNEL' : 
                    currentPhase === 'target' ? 'TARGET' : 
                    currentPhase === 'search' ? 'SEARCH' : 
                    currentPhase === 'watching' ? 'WATCHING' : 
                    currentPhase === 'idle' ? 'IDLE' : 'READY';
  
  const viewersProgress = targetViewers > 0 ? (currentViewers / targetViewers) * 100 : 0;
  
  const minutes = Math.floor(watchElapsed / 60);
  const seconds = watchElapsed % 60;
  const timeString = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  
  const progressPercent = totalWatchTime > 0 ? Math.min(100, (watchElapsed / totalWatchTime) * 100) : 0;
  
  hudElement.innerHTML = `
    <div class="hud-container" style="
      background: rgba(0, 0, 0, 0.9);
      backdrop-filter: blur(10px);
      border-radius: 15px;
      padding: 15px 25px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.8), 0 0 0 2px rgba(255,0,0,0.5);
      border: 1px solid rgba(255,255,255,0.3);
      color: white;
      width: 450px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    ">
      <!-- Baris 1: Logo dan Status -->
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <div style="display: flex; align-items: center; gap: 10px;">
          <span style="font-size: 20px;">🤖</span>
          <span style="font-weight: 800; font-size: 16px; background: linear-gradient(135deg, #fff, #ff0000); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">YT RAHMAN</span>
        </div>
        <div style="display: flex; align-items: center; gap: 15px;">
          <div style="display: flex; align-items: center; gap: 5px; background: rgba(255,255,255,0.1); padding: 5px 12px; border-radius: 20px;">
            <span style="width: 10px; height: 10px; border-radius: 50%; background: ${botActive ? '#4caf50' : '#f44336'}; box-shadow: 0 0 10px ${botActive ? '#4caf50' : '#f44336'};"></span>
            <span style="font-size: 12px;">${botActive ? 'ACTIVE' : 'STOPPED'}</span>
          </div>
          <div style="display: flex; align-items: center; gap: 5px; background: rgba(0,0,0,0.5); padding: 5px 12px; border-radius: 20px;">
            <span>⏱️</span>
            <span style="font-weight: 700; color: #ff0000; font-family: monospace; font-size: 16px;" id="hud-timer">${timeString}</span>
          </div>
        </div>
      </div>
      
      <!-- Baris 2: Phase dan Progress Video -->
      <div style="display: flex; align-items: center; gap: 15px;">
        <div style="padding: 5px 15px; border-radius: 20px; font-size: 13px; font-weight: 700; background: rgba(255,0,0,0.3); border: 2px solid #ff0000; color: #ff0000; min-width: 90px; text-align: center;">
          ${phaseText}
        </div>
        <div style="flex: 1; display: flex; align-items: center; gap: 10px;">
          <div style="flex: 1; height: 8px; background: rgba(255,255,255,0.2); border-radius: 4px; overflow: hidden;">
            <div style="height: 100%; background: linear-gradient(90deg, #ff0000, #ff6b6b); width: ${progressPercent}%; transition: width 0.3s; box-shadow: 0 0 10px #ff0000;" id="hud-progress-fill"></div>
          </div>
          <span style="font-size: 13px; font-weight: 700; color: #ff0000; min-width: 45px;" id="hud-progress-text">${Math.round(progressPercent)}%</span>
        </div>
      </div>
      
      <!-- Baris 3: Stats -->
      <div style="display: flex; justify-content: space-around; background: rgba(0,0,0,0.5); padding: 8px; border-radius: 10px;">
        <div style="text-align: center;">
          <div style="font-size: 11px; opacity: 0.7;">SESI</div>
          <div style="font-size: 18px; font-weight: 800; color: #ff0000;" id="hud-sessions">${stats.sessionsCompleted}</div>
        </div>
        <div style="text-align: center;">
          <div style="font-size: 11px; opacity: 0.7;">VIEWERS</div>
          <div style="font-size: 18px; font-weight: 800; color: #ff0000;" id="hud-viewers">${currentViewers}</div>
        </div>
        <div style="text-align: center;">
          <div style="font-size: 11px; opacity: 0.7;">TARGET</div>
          <div style="font-size: 18px; font-weight: 800; color: #ff0000;" id="hud-target">${targetViewers}</div>
        </div>
      </div>
      
      <!-- Baris 4: Target Progress -->
      <div style="background: rgba(255,255,255,0.1); padding: 8px 12px; border-radius: 10px;">
        <div style="display: flex; justify-content: space-between; font-size: 11px; margin-bottom: 5px;">
          <span>TARGET VIEWERS</span>
          <span id="target-text">${currentViewers}/${targetViewers}</span>
        </div>
        <div style="height: 6px; background: rgba(255,255,255,0.2); border-radius: 3px; overflow: hidden;">
          <div style="height: 100%; background: linear-gradient(90deg, #4caf50, #8bc34a); width: ${viewersProgress}%; transition: width 0.3s; box-shadow: 0 0 10px #4caf50;" class="target-bar-fill"></div>
        </div>
      </div>
      
      <!-- Baris 5: Durasi -->
      <div style="display: flex; justify-content: center; background: rgba(255,255,255,0.05); padding: 5px; border-radius: 20px; font-size: 11px;">
        <span>DURASI: </span>
        <span style="font-weight: 700; color: #ff9800; margin-left: 5px;" id="hud-duration">${totalWatchTime}s</span>
      </div>
    </div>
  `;
  
  hudElement.style.cssText = `
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    position: fixed !important;
    bottom: 20px !important;
    right: 20px !important;
    left: auto !important;
    transform: none !important;
    z-index: 1000000001 !important;
    pointer-events: none !important;
    max-width: 500px !important;
  `;
  
  document.body.appendChild(hudElement);
  console.log('✅ HUD DIBUAT dengan ID durasi = hud-duration');
  console.log('✅ totalWatchTime =', totalWatchTime);
}

// ============ FUNGSI TIMER ============
function startTimerUpdate() {
  if (timerInterval) clearInterval(timerInterval);
  
  timerInterval = setInterval(() => {
    if (!botActive) {
      console.log('⏸️ Timer stopped (bot not active)');
      return;
    }
    
    // Debug log setiap 5 detik
    if (watchElapsed % 5 === 0) {
      console.log(`⏱️ Timer running: isWatching=${isWatching}, watchStartTime=${watchStartTime ? 'YES' : 'NO'}`);
    }
    
    // HITUNG WATCH ELAPSED DENGAN BENAR
    if (isWatching && watchStartTime) {
      // Hitung selisih waktu dari watchStartTime sampai sekarang
      const now = Date.now();
      watchElapsed = Math.floor((now - watchStartTime) / 1000);
      
      // Batasi agar tidak melebihi totalWatchTime
      if (totalWatchTime > 0 && watchElapsed > totalWatchTime) {
        watchElapsed = totalWatchTime;
      }
      
      // Debug: log setiap 5 detik
      if (watchElapsed % 5 === 0) {
        console.log(`⏱️ Timer: ${watchElapsed}/${totalWatchTime} detik`);
      }
    }
    
    // Update HUD jika ada
    if (hudElement) {
      // Update timer (waktu yang sudah ditonton)
      const minutes = Math.floor(watchElapsed / 60);
      const seconds = watchElapsed % 60;
      const timerEl = document.getElementById('hud-timer');
      if (timerEl) {
        timerEl.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
      }
      
      // Update progress bar video
      if (totalWatchTime > 0) {
        const progressPercent = Math.min(100, (watchElapsed / totalWatchTime) * 100);
        const progressFill = document.getElementById('hud-progress-fill');
        const progressText = document.getElementById('hud-progress-text');
        if (progressFill) {
          progressFill.style.width = `${progressPercent}%`;
        }
        if (progressText) {
          progressText.textContent = `${Math.round(progressPercent)}%`;
        }
      }
      
      // Update durasi total (target durasi)
      const durationEl = document.getElementById('hud-duration');
      if (durationEl) {
        durationEl.textContent = `${totalWatchTime}s`;
      }
      
      // Update target progress
      const viewersProgress = targetViewers > 0 ? (currentViewers / targetViewers) * 100 : 0;
      const targetBar = hudElement.querySelector('.target-bar-fill');
      const targetText = document.getElementById('target-text');
      if (targetBar) targetBar.style.width = `${viewersProgress}%`;
      if (targetText) targetText.textContent = `${currentViewers}/${targetViewers}`;
      
      // Update stat lainnya
      const sessionsEl = document.getElementById('hud-sessions');
      const viewersEl = document.getElementById('hud-viewers');
      const targetEl = document.getElementById('hud-target');
      
      if (sessionsEl) sessionsEl.textContent = stats.sessionsCompleted;
      if (viewersEl) viewersEl.textContent = currentViewers;
      if (targetEl) targetEl.textContent = targetViewers;
    }
  }, 100); // Update setiap 100ms untuk responsif
}

function updateHUD(data) {
  if (!hudElement) createHUD();
  
  if (data.phase) {
    currentPhase = data.phase;
    const phaseEl = hudElement.querySelector('.hud-phase');
    if (phaseEl) {
      phaseEl.textContent = data.phase.toUpperCase();
      phaseEl.className = `hud-phase ${data.phase}`;
    }
  }
  
  if (data.sessions !== undefined) {
    const sessionsEl = document.getElementById('hud-sessions');
    if (sessionsEl) sessionsEl.textContent = data.sessions;
    stats.sessionsCompleted = data.sessions;
  }
  
  if (data.viewers !== undefined) {
    const viewersEl = document.getElementById('hud-viewers');
    if (viewersEl) viewersEl.textContent = data.viewers;
    currentViewers = data.viewers;
  }
  
  if (data.target !== undefined) {
    const targetEl = document.getElementById('hud-target');
    if (targetEl) targetEl.textContent = data.target;
    targetViewers = data.target;
  }
}

function findRandomChannelVideo() {
  currentPhase = 'channel';
  updatePhase('channel');
  updateHUD({ phase: 'channel' });
  
  console.log('🔍 Mencari video random dari channel @tripoint-t6z...');
  
  // Fungsi untuk scroll secara acak dan mengumpulkan semua video
  const collectAllVideos = async () => {
    console.log('📜 Memulai scroll untuk mengumpulkan semua video...');
    
    // Simpan posisi scroll awal
    const initialScrollY = window.scrollY;
    const videoSet = new Set(); // Gunakan Set untuk menghindari duplikat
    
    // Scroll ke atas dulu
    window.scrollTo(0, 0);
    await sleep(2000);
    
    // Kumpulkan video di posisi awal
    collectVideosAtCurrentPosition(videoSet);
    
    // Scroll ke bawah secara bertahap
    const scrollSteps = 8; // Jumlah langkah scroll
    for (let i = 0; i < scrollSteps; i++) {
      // Scroll ke bawah dengan variasi
      const scrollAmount = window.innerHeight * (0.8 + Math.random() * 0.4);
      window.scrollBy(0, scrollAmount);
      await sleep(1500 + Math.random() * 1000);
      
      // Kumpulkan video di posisi baru
      collectVideosAtCurrentPosition(videoSet);
      
      // Tampilkan progress
      console.log(`📊 Scroll step ${i + 1}/${scrollSteps}, video terkumpul: ${videoSet.size}`);
    }
    
    // Scroll ke atas lagi untuk mengumpulkan yang mungkin terlewat
    window.scrollTo(0, 0);
    await sleep(2000);
    collectVideosAtCurrentPosition(videoSet);
    
    // Scroll ke posisi random untuk mengambil video
    const randomScrollY = Math.random() * document.body.scrollHeight * 0.7;
    window.scrollTo(0, randomScrollY);
    await sleep(1500);
    collectVideosAtCurrentPosition(videoSet);
    
    console.log(`✅ Total video terkumpul: ${videoSet.size}`);
    return Array.from(videoSet);
  };
  
  // Fungsi untuk mengumpulkan video di posisi scroll saat ini
  const collectVideosAtCurrentPosition = (videoSet) => {
    // Multiple selectors untuk mendeteksi video
    const selectors = [
      'ytd-grid-video-renderer',
      'ytd-video-renderer',
      'ytd-rich-item-renderer',
      'ytd-rich-grid-media',
      '#contents ytd-grid-video-renderer',
      '#items ytd-grid-video-renderer',
      'ytd-compact-video-renderer',
      'a#thumbnail[href*="/watch"]',
      '#dismissible',
      'ytd-playlist-renderer'
    ];
    
    for (const selector of selectors) {
      const elements = document.querySelectorAll(selector);
      elements.forEach(el => {
        // Cek apakah element ini benar-benar video (bukan shorts/playlist)
        const link = el.querySelector('a[href*="/watch"]');
        if (link) {
          videoSet.add(el);
        }
      });
    }
    
    // Juga cari thumbnail yang mengarah ke video
    const thumbnails = document.querySelectorAll('a#thumbnail[href*="/watch"]');
    thumbnails.forEach(thumb => {
      const parent = thumb.closest('ytd-grid-video-renderer, ytd-video-renderer, ytd-rich-item-renderer');
      if (parent) {
        videoSet.add(parent);
      } else {
        videoSet.add(thumb);
      }
    });
  };
  
  // Eksekusi pengumpulan video
  setTimeout(async () => {
    const allVideos = await collectAllVideos();
    
    if (allVideos.length === 0) {
      console.log('⚠️ Tidak menemukan video, mencoba method alternatif...');
      
      // Fallback: scroll manual dan coba lagi
      for (let i = 0; i < 5; i++) {
        window.scrollTo(0, document.body.scrollHeight * Math.random());
        await sleep(2000);
        
        const videos = document.querySelectorAll('ytd-grid-video-renderer, ytd-video-renderer, a#thumbnail[href*="/watch"]');
        if (videos.length > 0) {
          allVideos.push(...Array.from(videos));
          break;
        }
      }
    }
    
    // Filter video yang valid (punya link watch)
    const validVideos = allVideos.filter(video => {
      const link = video.querySelector('a[href*="/watch"]') || 
                   (video.tagName === 'A' && video.getAttribute('href')?.includes('/watch') ? video : null);
      return link !== null;
    });
    
    if (validVideos.length === 0) {
      handleError('Tidak ada video valid setelah scroll');
      return;
    }
    
    // Pilih video secara acak dari semua yang terkumpul
    const randomIndex = Math.floor(Math.random() * validVideos.length);
    const selectedVideo = validVideos[randomIndex];
    
    console.log(`🎯 Memilih video random index ${randomIndex + 1} dari ${validVideos.length} video (bukan hanya video atas)`);
    
    // Scroll ke posisi video terpilih
    if (selectedVideo) {
      selectedVideo.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await sleep(1500);
    }
    
    // Highlight video yang dipilih
    if (pointerVisible) await moveMouseToElement(selectedVideo);
    highlightElement(selectedVideo, '#ff0000');
    
    // Dapatkan link video
    const videoUrl = await getVideoUrlFromElement(selectedVideo);
    
    if (videoUrl) {
      console.log('📺 Menuju video:', videoUrl);
      
      // SIMPAN STATE SEBELUM NAVIGASI
      navigationInProgress = true;
      
      sessionStorage.setItem('botActive', botActive);
      sessionStorage.setItem('botSettings', JSON.stringify(settings));
      sessionStorage.setItem('botStats', JSON.stringify(stats));
      sessionStorage.setItem('botCurrentViewers', currentViewers);
      sessionStorage.setItem('botTargetViewers', targetViewers);
      sessionStorage.setItem('botPhase', currentPhase);
      sessionStorage.setItem('botPointerVisible', pointerVisible);
      sessionStorage.setItem('botShowHud', settings?.showHud || false);
      sessionStorage.setItem('botShowPointer', settings?.showPointer || false);
      sessionStorage.setItem('botSessionTabId', sessionTabId);
      
      window.location.href = videoUrl;
    } else {
      console.error('❌ Tidak bisa mendapatkan URL video, mencoba klik thumbnail...');
      const thumbnail = selectedVideo.querySelector('a#thumbnail[href*="/watch"]') || 
                       (selectedVideo.tagName === 'A' ? selectedVideo : null);
      if (thumbnail) {
        sessionStorage.setItem('botActive', botActive);
        sessionStorage.setItem('botSettings', JSON.stringify(settings));
        sessionStorage.setItem('botStats', JSON.stringify(stats));
        sessionStorage.setItem('botCurrentViewers', currentViewers);
        sessionStorage.setItem('botTargetViewers', targetViewers);
        sessionStorage.setItem('botPhase', currentPhase);
        sessionStorage.setItem('botPointerVisible', pointerVisible);
        sessionStorage.setItem('botShowHud', settings?.showHud || false);
        sessionStorage.setItem('botShowPointer', settings?.showPointer || false);
        sessionStorage.setItem('botSessionTabId', sessionTabId);
        
        thumbnail.click();
      } else {
        handleError('Tidak bisa membuka video');
      }
    }
  }, 2000);
}

// Fungsi baru: tunggu channel content load
function waitForChannelContent() {
  return new Promise((resolve) => {
    // Cek apakah sudah ada video
    const checkExist = setInterval(() => {
      const videos = document.querySelectorAll('ytd-grid-video-renderer, ytd-video-renderer, ytd-rich-item-renderer, a#thumbnail[href*="/watch"]');
      if (videos.length > 0) {
        clearInterval(checkExist);
        resolve();
      }
    }, 500);
    
    // Timeout setelah 15 detik
    setTimeout(() => {
      clearInterval(checkExist);
      resolve();
    }, 15000);
  });
}

// Fungsi baru: extract link video dari element
function getVideoLinkFromElement(element) {
  // Coba berbagai selector
  const selectors = [
    'a#thumbnail[href*="/watch"]',
    'a#video-title[href*="/watch"]',
    'a[href*="/watch"]'
  ];
  
  for (const selector of selectors) {
    const linkElement = element.querySelector(selector);
    if (linkElement) {
      const href = linkElement.getAttribute('href');
      if (href) return href;
    }
  }
  
  // Jika element itu sendiri adalah link
  if (element.tagName === 'A' && element.hasAttribute('href')) {
    const href = element.getAttribute('href');
    if (href && href.includes('/watch')) return href;
  }
  
  return null;
}

// Fungsi baru: dapatkan URL lengkap dari element
async function getVideoUrlFromElement(element) {
  const href = getVideoLinkFromElement(element);
  if (!href) return null;
  
  // Jika sudah full URL
  if (href.startsWith('http')) return href;
  
  // Jika relative path
  return `https://www.youtube.com${href}`;
}

// ============ FUNGSI START WATCHING CHANNEL VIDEO ============
async function startWatchingChannelVideo() {
  // PASTIKAN OVERLAY ADA
  if (!document.getElementById('bot-protective-overlay')) {
    console.log('Membuat overlay di awal watching...');
    createProtectiveOverlay();
  }
  
  // MULAI MONITORING OVERLAY
  if (overlayCheckInterval) clearInterval(overlayCheckInterval);
  overlayCheckInterval = setInterval(() => {
    if (botActive && !document.getElementById('bot-protective-overlay')) {
      console.log('⚠️ Overlay hilang saat watching, buat ulang...');
      createProtectiveOverlay();
    }
  }, 500);
  
  currentPhase = 'watching';
  isWatching = true;
  updatePhase('watching');
  
  // Multiple selectors untuk video player
  const videoSelectors = [
    'video',
    'video.video-stream',
    '.html5-main-video',
    '#movie_player video',
    '.video-stream'
  ];
  
  for (const selector of videoSelectors) {
    videoPlayer = document.querySelector(selector);
    if (videoPlayer) break;
  }
  
  if (!videoPlayer) {
    videoPlayer = await waitForElement('video', 15000);
  }
  
  if (!videoPlayer) {
    handleError('Video player tidak ditemukan');
    return;
  }
  
  console.log('✅ Video player ditemukan');
  
  // Pastikan overlay ada
  if (!document.getElementById('bot-protective-overlay')) {
    createProtectiveOverlay();
  }
  
  if (pointerVisible) await moveMouseToElement(videoPlayer);
  await ensureAudioPlayback();
  
  // Tunggu metadata video
  await waitForVideoMetadata();
  
  const videoDuration = videoPlayer.duration;
  console.log('📊 Durasi video:', videoDuration, 'detik');
  
  if (!videoDuration || videoDuration === Infinity || isNaN(videoDuration) || videoDuration <= 0) {
    handleError('Tidak dapat membaca durasi video');
    return;
  }
  
  // SET totalWatchTime
  const watchPercentage = getRandomInt(80, 100) / 100;
  totalWatchTime = Math.floor(videoDuration * watchPercentage);
  console.log(`⏱️ Akan menonton ${Math.round(watchPercentage * 100)}% (${totalWatchTime} detik)`);
  
  // Update HUD dengan totalWatchTime yang benar
  if (hudElement) {
    const durationEl = document.getElementById('hud-duration');
    if (durationEl) {
      durationEl.textContent = `${totalWatchTime}s`;
      console.log('✅ HUD duration di-update menjadi:', totalWatchTime + 's');
    }
  }
  
  // RESET TIMER
  watchElapsed = 0;
  watchStartTime = Date.now();
  lastVideoTime = 0;
  
  console.log(`🎬 Mulai menonton pada: ${new Date(watchStartTime).toLocaleTimeString()}`);
  
  // PASTIKAN TIMER INTERVAL BERJALAN
  if (timerInterval) clearInterval(timerInterval);
  startTimerUpdate();
  
  updateHUD({ phase: 'watching' });
  if (!hudElement && settings.showHud) createHUD();
  
  startVideoMonitoring();
  startScrollingSimulation();
  
  stats.channelVideosWatched++;
  updateHUDStats();
  saveStats();
  
  if (watchTimer) clearTimeout(watchTimer);
  watchTimer = setTimeout(finishChannelVideo, totalWatchTime * 1000);
}

function waitForVideoMetadata() {
  return new Promise((resolve) => {
    if (videoPlayer && videoPlayer.duration && videoPlayer.duration !== Infinity && !isNaN(videoPlayer.duration) && videoPlayer.duration > 0) {
      resolve();
      return;
    }
    
    const checkInterval = setInterval(() => {
      if (videoPlayer && videoPlayer.duration && videoPlayer.duration !== Infinity && !isNaN(videoPlayer.duration) && videoPlayer.duration > 0) {
        clearInterval(checkInterval);
        resolve();
      }
    }, 500);
    
    setTimeout(() => {
      clearInterval(checkInterval);
      resolve();
    }, 10000);
  });
}

function startVideoMonitoring() {
  if (!videoPlayer) return;
  
  if (videoProgressListener) videoPlayer.removeEventListener('timeupdate', videoProgressListener);
  if (speedChangeListener) videoPlayer.removeEventListener('ratechange', speedChangeListener);
  
  videoProgressListener = () => {
    if (!isWatching || !videoPlayer || !botActive) return;
    
    const currentTime = videoPlayer.currentTime;
    
    if (lastVideoTime > 0 && Math.abs(currentTime - lastVideoTime) > 5) {
      console.log('⚠️ Video seek detected!');
      showErrorToast('Dilarang menggeser video!');
      videoPlayer.currentTime = lastVideoTime;
    }
    
    lastVideoTime = currentTime;
  };
  
  speedChangeListener = () => {
    if (!isWatching || !videoPlayer || !botActive) return;
    
    const currentRate = videoPlayer.playbackRate;
    
    if (Math.abs(currentRate - 1.0) > 0.1) {
      console.log(`⚠️ Speed change detected: ${currentRate}x`);
      showErrorToast('Dilarang mempercepat video!');
      videoPlayer.playbackRate = 1.0;
    }
  };
  
  videoPlayer.addEventListener('timeupdate', videoProgressListener);
  videoPlayer.addEventListener('ratechange', speedChangeListener);
  
  // Lock playback rate
  try {
    Object.defineProperty(videoPlayer, 'playbackRate', {
      get: function() { return this._playbackRate || 1.0; },
      set: function(val) { 
        console.log('⛔ Mencegah perubahan playback rate');
        this._playbackRate = 1.0; 
      }
    });
  } catch (e) {
    console.log('Tidak bisa lock playbackRate');
  }
}

function finishChannelVideo() {
  console.log('✅ Selesai menonton video channel');
  
  isWatching = false;
  
  if (videoPlayer) {
    if (videoProgressListener) videoPlayer.removeEventListener('timeupdate', videoProgressListener);
    if (speedChangeListener) videoPlayer.removeEventListener('ratechange', speedChangeListener);
  }
  
  if (watchTimer) clearTimeout(watchTimer);
  if (scrollInterval) clearInterval(scrollInterval);
  if (overlayCheckInterval) clearInterval(overlayCheckInterval);
  
  currentViewers++;
  stats.sessionsCompleted++;
  
  updateHUDStats();
  saveStats();
  
  chrome.runtime.sendMessage({
    action: 'sessionComplete',
    tabId: sessionTabId,
    stats: stats,
    viewers: currentViewers
  });
  
  showSuccessToast(`Channel selesai! Total viewers: ${currentViewers}`);
  
  watchElapsed = 0;
  watchStartTime = null;
  
  console.log('➡️ Berikutnya: menonton video target');
  
  setTimeout(() => {
    if (botActive) window.location.href = 'https://www.youtube.com';
  }, 2000);
}

async function startSearchMode() {
  currentPhase = 'search';
  updatePhase('search');
  updateHUD({ phase: 'search' });
  
  const videoTitles = settings.targetTitles.split(',').map(title => title.trim()).filter(title => title);
  if (videoTitles.length === 0) {
    handleError('Tidak ada judul video');
    return;
  }
  
  const titleIndex = currentTargetIndex % videoTitles.length;
  const searchQuery = videoTitles[titleIndex];
  
  console.log(`🔍 Mencari target ${titleIndex + 1}: "${searchQuery}"`);
  currentTargetIndex++;
  
  // Cari search box
  let searchBox = null;
  const searchSelectors = [
    'input#search',
    'input[name="search_query"]',
    'ytd-searchbox input',
    '#search-input input'
  ];
  
  for (let i = 0; i < 30; i++) {
    for (const selector of searchSelectors) {
      searchBox = document.querySelector(selector);
      if (searchBox && searchBox.offsetParent !== null) break;
    }
    if (searchBox) break;
    await sleep(1000);
  }
  
  if (!searchBox) {
    handleError('Search box tidak ditemukan');
    return;
  }
  
  if (pointerVisible) await moveMouseToElement(searchBox);
  
  searchBox.style.border = '2px solid red';
  searchBox.focus();
  searchBox.click();
  searchBox.value = '';
  
  await humanLikeTyping(searchBox, searchQuery);
  await sleep(getRandomInt(300, 800));
  
  const enterEvent = new KeyboardEvent('keydown', {
    key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
    bubbles: true, cancelable: true
  });
  searchBox.dispatchEvent(enterEvent);
  
  setTimeout(() => findAndClickTargetVideo(searchQuery), 3000);
}

async function humanLikeTyping(element, text) {
  return new Promise(async (resolve) => {
    for (let i = 0; i < text.length; i++) {
      element.value = text.substring(0, i + 1);
      
      element.dispatchEvent(new Event('input', { bubbles: true }));
      element.dispatchEvent(new Event('keydown', { bubbles: true }));
      element.dispatchEvent(new Event('keyup', { bubbles: true }));
      
      if (mousePointer && pointerVisible) {
        const rect = element.getBoundingClientRect();
        mouseX = rect.left + (rect.width * 0.5) + (Math.random() * 15 - 7.5);
        mouseY = rect.top + (rect.height * 0.5) + (Math.random() * 15 - 7.5);
        updatePointerPosition();
      }
      
      let delay = getRandomInt(80, 200);
      if (text[i] === ' ') delay = getRandomInt(300, 500);
      if (i > 0 && text[i-1] === ' ') delay = getRandomInt(200, 350);
      
      await sleep(delay);
    }
    await sleep(getRandomInt(300, 600));
    resolve();
  });
}

async function findAndClickTargetVideo(searchQuery) {
  await sleep(3000);
  
  const videoSelectors = [
    'ytd-video-renderer',
    'ytd-compact-video-renderer',
    'ytd-rich-item-renderer',
    '#contents ytd-video-renderer'
  ];
  
  let videos = [];
  for (const selector of videoSelectors) {
    videos = document.querySelectorAll(selector);
    if (videos.length > 0) break;
  }
  
  if (videos.length === 0) {
    handleError('Tidak ada video di hasil pencarian');
    return;
  }
  
  let targetVideo = videos[0];
  
  // Cari video dengan judul yang mirip
  for (let i = 0; i < Math.min(10, videos.length); i++) {
    const titleEl = videos[i].querySelector('#video-title, a#video-title, yt-formatted-string');
    if (titleEl && titleEl.textContent.toLowerCase().includes(searchQuery.toLowerCase())) {
      targetVideo = videos[i];
      break;
    }
  }
  
  if (pointerVisible) await moveMouseToElement(targetVideo);
  highlightElement(targetVideo, '#4caf50');
  
  const videoLink = targetVideo.querySelector('a#video-title, a[href*="watch"], #thumbnail');
  if (videoLink) {
    if (pointerVisible) await moveMouseToElement(videoLink);
    videoLink.click();
    setTimeout(startWatchingTargetVideo, 4000);
  } else {
    handleError('Tidak bisa klik video');
  }
}

// ============ FUNGSI START WATCHING TARGET VIDEO ============
async function startWatchingTargetVideo() {
  // PASTIKAN OVERLAY ADA
  if (!document.getElementById('bot-protective-overlay')) {
    console.log('Membuat overlay di awal watching target...');
    createProtectiveOverlay();
  }
  
  // MULAI MONITORING OVERLAY
  if (overlayCheckInterval) clearInterval(overlayCheckInterval);
  overlayCheckInterval = setInterval(() => {
    if (botActive && !document.getElementById('bot-protective-overlay')) {
      console.log('⚠️ Overlay hilang saat watching target, buat ulang...');
      createProtectiveOverlay();
    }
  }, 500);
  
  currentPhase = 'target';
  isWatching = true;
  updatePhase('target');
  
  // DETEKSI VIDEO PLAYER YANG LEBIH BAIK
  console.log('🔍 Mencari video player untuk video target...');
  
  // Tunggu hingga halaman benar-benar load
  await sleep(5000);
  
  // Coba berbagai selector untuk video player
  const videoSelectors = [
    'video',
    'video.video-stream',
    '.html5-main-video',
    '#movie_player video',
    '.video-stream',
    'video#movie_player',
    '#player-container video',
    'ytd-player video',
    '#ytd-player video',
    '.html5-video-player video',
    '#player-api video',
    '#player-container-id video'
  ];
  
  // Coba setiap selector
  for (const selector of videoSelectors) {
    videoPlayer = document.querySelector(selector);
    if (videoPlayer) {
      console.log(`✅ Video player ditemukan dengan selector: ${selector}`);
      break;
    }
  }
  
  // Jika belum ditemukan, coba dengan waitForElement yang lebih lama
  if (!videoPlayer) {
    console.log('⏳ Menunggu video player muncul (20 detik)...');
    videoPlayer = await waitForElement('video', 20000);
  }
  
  // Jika masih tidak ada, coba inject ke dalam iframe
  if (!videoPlayer) {
    console.log('🔍 Mencari video player di dalam iframe...');
    const iframes = document.querySelectorAll('iframe');
    for (const iframe of iframes) {
      try {
        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
        videoPlayer = iframeDoc.querySelector('video');
        if (videoPlayer) {
          console.log('✅ Video player ditemukan di iframe');
          break;
        }
      } catch (e) {
        // Cross-origin iframe, tidak bisa diakses
        console.log('Iframe tidak bisa diakses (cross-origin)');
      }
    }
  }
  
  // Coba klik tombol play jika video player belum ditemukan
  if (!videoPlayer) {
    console.log('Mencoba klik tombol play untuk memunculkan video player...');
    const playButton = document.querySelector('.ytp-large-play-button, .ytp-play-button, button[aria-label="Play"]');
    if (playButton) {
      if (pointerVisible) await moveMouseToElement(playButton);
      playButton.click();
      await sleep(3000);
      videoPlayer = document.querySelector('video');
    }
  }
  
  // Cek apakah video player ditemukan
  if (!videoPlayer) {
    console.error('❌ Video player TIDAK ditemukan setelah semua percobaan');
    
    // Coba cek apakah halaman adalah shorts
    if (window.location.href.includes('/shorts/')) {
      console.log('Ini adalah halaman Shorts, mencoba deteksi player shorts...');
      const shortsVideo = document.querySelector('video');
      if (shortsVideo) {
        videoPlayer = shortsVideo;
        console.log('✅ Video player Shorts ditemukan');
      }
    } else {
      handleError('Video player tidak ditemukan');
      return;
    }
  }
  
  if (!videoPlayer) {
    handleError('Video player tidak ditemukan');
    return;
  }
  
  console.log('✅ Video player berhasil ditemukan dan siap digunakan');
  
  // Pastikan overlay ada
  if (!document.getElementById('bot-protective-overlay')) {
    createProtectiveOverlay();
  }
  
  if (pointerVisible) await moveMouseToElement(videoPlayer);
  await ensureAudioPlayback();
  
  // SET totalWatchTime
  totalWatchTime = getRandomInt(settings.targetMin, settings.targetMax);
  console.log(`⏱️ Akan menonton target selama ${totalWatchTime} detik`);
  
  // Update HUD dengan totalWatchTime yang benar
  if (hudElement) {
    const durationEl = document.getElementById('hud-duration');
    if (durationEl) {
      durationEl.textContent = `${totalWatchTime}s`;
      console.log('✅ HUD duration di-update menjadi:', totalWatchTime + 's');
    }
  }
  
  // RESET TIMER
  watchElapsed = 0;
  watchStartTime = Date.now();
  lastVideoTime = 0;
  
  console.log(`🎬 Mulai menonton target pada: ${new Date(watchStartTime).toLocaleTimeString()}`);
  
  // PASTIKAN TIMER INTERVAL BERJALAN
  if (timerInterval) clearInterval(timerInterval);
  startTimerUpdate();
  
  updateHUD({ phase: 'target' });
  if (!hudElement && settings.showHud) createHUD();
  
  startVideoMonitoring();
  startScrollingSimulation();
  
  stats.targetVideosWatched++;
  updateHUDStats();
  saveStats();
  
  if (watchTimer) clearTimeout(watchTimer);
  watchTimer = setTimeout(finishTargetVideo, totalWatchTime * 1000);
}

function finishTargetVideo() {
  console.log('✅ Selesai menonton video target');
  
  isWatching = false;
  
  if (videoPlayer) {
    if (videoProgressListener) videoPlayer.removeEventListener('timeupdate', videoProgressListener);
    if (speedChangeListener) videoPlayer.removeEventListener('ratechange', speedChangeListener);
  }
  
  if (watchTimer) clearTimeout(watchTimer);
  if (scrollInterval) clearInterval(scrollInterval);
  if (overlayCheckInterval) clearInterval(overlayCheckInterval);
  
  currentViewers++;
  stats.sessionsCompleted++;
  
  updateHUDStats();
  saveStats();
  
  chrome.runtime.sendMessage({
    action: 'sessionComplete',
    tabId: sessionTabId,
    stats: stats,
    viewers: currentViewers
  });
  
  showSuccessToast(`Target selesai! Total viewers: ${currentViewers}`);
  
  watchElapsed = 0;
  watchStartTime = null;
  
  console.log('➡️ Berikutnya: kembali ke channel');
  
  setTimeout(() => {
    if (botActive) window.location.href = CHANNEL_URL;
  }, 2000);
}

function highlightElement(element, color) {
  const highlight = document.createElement('div');
  highlight.style.cssText = `
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border: 4px solid ${color};
    box-shadow: 0 0 30px ${color};
    z-index: 9999;
    pointer-events: none;
    animation: highlightPulse 1s infinite;
    border-radius: 8px;
  `;
  
  if (getComputedStyle(element).position === 'static') {
    element.style.position = 'relative';
  }
  
  element.appendChild(highlight);
  setTimeout(() => highlight.remove(), 2000);
}

async function ensureAudioPlayback() {
  if (!videoPlayer) return;
  
  videoPlayer.muted = false;
  videoPlayer.volume = 0.3;
  
  try {
    await videoPlayer.play();
    console.log('Video playback started');
  } catch (error) {
    console.log('Autoplay blocked, simulating click...', error);
    
    const player = document.querySelector('.html5-video-player, #movie_player, .ytp-cued-thumbnail-overlay, .ytp-large-play-button');
    if (player) {
      if (pointerVisible) await moveMouseToElement(player);
      player.click();
      console.log('Clicked play button');
      setTimeout(() => {
        videoPlayer.play().catch(e => console.log('Still cannot play:', e));
      }, 500);
    }
  }
}

function startScrollingSimulation() {
  if (scrollInterval) clearInterval(scrollInterval);
  
  // Scroll secara acak (atas/bawah) dengan variasi jarak
  scrollInterval = setInterval(() => {
    if (!botActive || !isWatching) return;
    
    // Scroll secara acak (atas/bawah) dengan variasi jarak
    const scrollDirections = ['up', 'down', 'random'];
    const direction = scrollDirections[Math.floor(Math.random() * scrollDirections.length)];
    
    let scrollAmount;
    let targetScrollY;
    
    switch(direction) {
      case 'up':
        scrollAmount = getRandomInt(100, 300);
        targetScrollY = Math.max(0, window.scrollY - scrollAmount);
        break;
      case 'down':
        scrollAmount = getRandomInt(100, 300);
        targetScrollY = Math.min(document.body.scrollHeight - window.innerHeight, window.scrollY + scrollAmount);
        break;
      case 'random':
        targetScrollY = Math.random() * (document.body.scrollHeight - window.innerHeight);
        break;
    }
    
    if (direction === 'random') {
      window.scrollTo({
        top: targetScrollY,
        behavior: 'smooth'
      });
    } else {
      window.scrollBy({
        top: direction === 'up' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
    
    // Update posisi mouse pointer mengikuti scroll
    if (pointerVisible && mousePointer) {
      // Sedikit gerakkan mouse secara random setelah scroll
      setTimeout(() => {
        mouseX = window.innerWidth / 2 + (Math.random() - 0.5) * 200;
        mouseY = window.innerHeight / 2 + (Math.random() - 0.5) * 150;
        updatePointerPosition();
      }, 500);
    }
    
    console.log(`🖱️ Scroll ${direction}, posisi: ${Math.round(window.scrollY)}px`);
    
  }, getRandomInt(4000, 8000)); // Scroll setiap 4-8 detik
}

function updatePhase(phase) {
  currentPhase = phase;
  if (hudElement) {
    const phaseEl = hudElement.querySelector('.hud-phase');
    if (phaseEl) {
      phaseEl.textContent = phase.toUpperCase();
      phaseEl.className = `hud-phase ${phase}`;
    }
  }
}

function updateHUDStats() {
  if (hudElement) {
    updateHUD({
      sessions: stats.sessionsCompleted,
      viewers: currentViewers,
      target: targetViewers
    });
  }
}

function saveStats() {
  chrome.storage.local.set({ botStats: stats });
}

function showSuccessToast(message) {
  const toast = document.createElement('div');
  toast.className = 'bot-success-toast';
  toast.innerHTML = `✅ ${message}`;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2000);
}

function stopBot() {
  botActive = false;
  isWatching = false;
  
  if (videoPlayer) {
    if (videoProgressListener) videoPlayer.removeEventListener('timeupdate', videoProgressListener);
    if (speedChangeListener) videoPlayer.removeEventListener('ratechange', speedChangeListener);
  }
  
  if (watchTimer) clearTimeout(watchTimer);
  if (scrollInterval) clearInterval(scrollInterval);
  if (mouseMoveInterval) clearInterval(mouseMoveInterval);
  if (hudCheckInterval) clearInterval(hudCheckInterval);
  if (timerInterval) clearInterval(timerInterval);
  if (overlayCheckInterval) clearInterval(overlayCheckInterval);
  
  removeProtectiveOverlay();
  
  if (hudElement) hudElement.remove();
  if (mousePointer) mousePointer.remove();
  
  hideMousePointer();
  
  // BERSIHKAN SESSION STORAGE
  sessionStorage.clear();
}

function waitForElement(selector, timeout = 20000) {
  return new Promise((resolve) => {
    const element = document.querySelector(selector);
    if (element) {
      console.log(`Elemen ${selector} sudah tersedia`);
      resolve(element);
      return;
    }
    
    console.log(`Menunggu elemen ${selector} muncul...`);
    const startTime = Date.now();
    
    const observer = new MutationObserver(() => {
      const element = document.querySelector(selector);
      if (element) {
        const elapsed = Date.now() - startTime;
        console.log(`✅ Elemen ${selector} ditemukan setelah ${elapsed}ms`);
        observer.disconnect();
        resolve(element);
      }
    });
    
    observer.observe(document.body, { 
      childList: true, 
      subtree: true,
      attributes: true,
      characterData: true 
    });
    
    setTimeout(() => { 
      observer.disconnect(); 
      console.log(`⏰ Timeout ${timeout}ms untuk elemen ${selector}`);
      resolve(null); 
    }, timeout);
  });
}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}