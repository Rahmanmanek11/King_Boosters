document.addEventListener('DOMContentLoaded', function() {
  // Load saved settings
  loadSettings();
  
  // Toggle sections based on mode
  document.getElementById('mode').addEventListener('change', function() {
    const mode = this.value;
    document.getElementById('search-section').style.display = mode === 'search' ? 'block' : 'none';
    document.getElementById('rekomendasi-section').style.display = mode === 'rekomendasi' ? 'block' : 'none';
    saveSettings();
  });
  
  // Save settings on input change
  const inputs = document.querySelectorAll('input, textarea, select');
  inputs.forEach(input => {
    input.addEventListener('change', saveSettings);
    input.addEventListener('keyup', debounce(saveSettings, 500));
  });
  
  // Start bot
  document.getElementById('start-bot').addEventListener('click', function() {
    saveSettings();
    showStatus('Memulai bot...', 'info');
    
    chrome.runtime.sendMessage({ action: 'startBot', settings: getSettings() }, function(response) {
      if (response && response.success) {
        showStatus('✅ Bot berjalan! Target: ' + getSettings().targetViewers + ' viewers', 'active');
        updateHeaderStatus(true);
        updateStats();
      } else {
        showStatus('❌ Gagal memulai: ' + (response?.error || 'unknown'), 'error');
      }
    });
  });
  
  // Stop bot
  document.getElementById('stop-bot').addEventListener('click', function() {
    chrome.runtime.sendMessage({ action: 'stopBot' }, function(response) {
      showStatus('⏹️ Bot dihentikan', 'error');
      updateHeaderStatus(false);
      updateStats();
    });
  });
  
  // Clear history now
  document.getElementById('clear-history').addEventListener('click', function() {
    chrome.runtime.sendMessage({ action: 'clearBrowsingData' }, function(response) {
      if (response && response.success) {
        showStatus('🧹 Data browsing dibersihkan!', 'active');
      } else {
        showStatus('❌ Gagal membersihkan data', 'error');
      }
    });
  });
  
  // Reset config
  document.getElementById('reset-config').addEventListener('click', function() {
    resetToDefault();
    saveSettings();
    showStatus('↺ Config direset ke default', 'info');
  });
  
  // Update stats periodically
  updateStats();
  setInterval(updateStats, 1000);
});

function getSettings() {
  return {
    mode: document.getElementById('mode').value,
    searchVideoIds: document.getElementById('search-video-ids').value,
    warmupLinks: document.getElementById('warmup-links').value,
    targetIds: document.getElementById('target-ids').value,
    warmupMin: parseInt(document.getElementById('warmup-min').value) || 30,
    warmupMax: parseInt(document.getElementById('warmup-max').value) || 60,
    targetMin: parseInt(document.getElementById('target-min').value) || 60,
    targetMax: parseInt(document.getElementById('target-max').value) || 120,
    tabCount: parseInt(document.getElementById('tab-count').value) || 1,
    delayMin: parseInt(document.getElementById('delay-min').value) || 5,
    delayMax: parseInt(document.getElementById('delay-max').value) || 15,
    targetViewers: parseInt(document.getElementById('target-viewers').value) || 100,
    autoWipe: document.getElementById('auto-wipe').checked,
    showPointer: document.getElementById('show-pointer').checked,
    showHud: document.getElementById('show-hud').checked,
    singleTab: document.getElementById('single-tab').checked
  };
}

function saveSettings() {
  const settings = getSettings();
  chrome.storage.local.set({ botSettings: settings });
}

function loadSettings() {
  chrome.storage.local.get(['botSettings', 'isRunning', 'currentViewers'], function(data) {
    if (data.botSettings) {
      const s = data.botSettings;
      document.getElementById('mode').value = s.mode || 'rekomendasi';
      document.getElementById('search-video-ids').value = s.searchVideoIds || 'dQw4w9WgXcQ, video123, abcdefg';
      document.getElementById('warmup-links').value = s.warmupLinks || 'https://www.youtube.com/watch?v=dQw4w9WgXcQ\nhttps://www.youtube.com/watch?v=video123';
      document.getElementById('target-ids').value = s.targetIds || 'target1, target2, target3';
      document.getElementById('warmup-min').value = s.warmupMin || 30;
      document.getElementById('warmup-max').value = s.warmupMax || 60;
      document.getElementById('target-min').value = s.targetMin || 60;
      document.getElementById('target-max').value = s.targetMax || 120;
      document.getElementById('tab-count').value = s.tabCount || 1;
      document.getElementById('delay-min').value = s.delayMin || 5;
      document.getElementById('delay-max').value = s.delayMax || 15;
      document.getElementById('target-viewers').value = s.targetViewers || 100;
      document.getElementById('auto-wipe').checked = s.autoWipe !== undefined ? s.autoWipe : true;
      document.getElementById('show-pointer').checked = s.showPointer !== undefined ? s.showPointer : true;
      document.getElementById('show-hud').checked = s.showHud !== undefined ? s.showHud : true;
      document.getElementById('single-tab').checked = s.singleTab !== undefined ? s.singleTab : true;
      
      // Trigger mode change
      document.getElementById('mode').dispatchEvent(new Event('change'));
    }
    
    // Update header status
    updateHeaderStatus(data.isRunning || false);
    
    // Show target progress if running
    if (data.isRunning && data.currentViewers !== undefined) {
      showTargetProgress(data.currentViewers, getSettings().targetViewers);
    }
  });
}

function resetToDefault() {
  document.getElementById('mode').value = 'rekomendasi';
  document.getElementById('search-video-ids').value = 'dQw4w9WgXcQ, video123, abcdefg';
  document.getElementById('warmup-links').value = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ\nhttps://www.youtube.com/watch?v=video123';
  document.getElementById('target-ids').value = 'target1, target2, target3';
  document.getElementById('warmup-min').value = 30;
  document.getElementById('warmup-max').value = 60;
  document.getElementById('target-min').value = 60;
  document.getElementById('target-max').value = 120;
  document.getElementById('tab-count').value = 1;
  document.getElementById('delay-min').value = 5;
  document.getElementById('delay-max').value = 15;
  document.getElementById('target-viewers').value = 100;
  document.getElementById('auto-wipe').checked = true;
  document.getElementById('show-pointer').checked = true;
  document.getElementById('show-hud').checked = true;
  document.getElementById('single-tab').checked = true;
  
  document.getElementById('mode').dispatchEvent(new Event('change'));
}

function showStatus(message, type) {
  const statusEl = document.getElementById('status-message');
  if (!statusEl) return;
  
  statusEl.style.display = 'block';
  statusEl.textContent = message;
  
  const colors = {
    active: '#d4edda',
    error: '#f8d7da',
    info: '#d1ecf1'
  };
  
  statusEl.style.background = colors[type] || '#e2e8f0';
  statusEl.style.color = type === 'error' ? '#721c24' : '#155724';
  
  setTimeout(() => {
    statusEl.style.display = 'none';
  }, 3000);
}

function updateHeaderStatus(running) {
  const headerStatus = document.getElementById('header-status');
  if (headerStatus) {
    headerStatus.innerHTML = running ? '🟢 Berjalan' : '⚪ Berhenti';
    headerStatus.style.background = running ? 'rgba(76, 175, 80, 0.3)' : 'rgba(255,255,255,0.2)';
  }
}

function showTargetProgress(current, target) {
  const container = document.getElementById('target-progress-container');
  const container2 = document.getElementById('target-progress-container2');
  const progressText = document.getElementById('target-progress-text');
  const progressText2 = document.getElementById('target-progress-text2');
  const progressFill = document.getElementById('target-progress-fill');
  const progressFill2 = document.getElementById('target-progress-fill2');
  
  if (container && target > 0) {
    container.style.display = 'block';
    container2.style.display = 'block';
    
    const percentage = Math.min(100, (current / target) * 100);
    
    if (progressText) progressText.textContent = `${current}/${target}`;
    if (progressText2) progressText2.textContent = `${Math.round(percentage)}%`;
    if (progressFill) progressFill.style.width = `${percentage}%`;
    if (progressFill2) progressFill2.style.width = `${percentage}%`;
  }
}

function updateStats() {
  chrome.runtime.sendMessage({ action: 'getStats' }, function(response) {
    if (response) {
      // Update stat values
      document.getElementById('stat-sessions').textContent = response.sessions || 0;
      document.getElementById('stat-tabs').textContent = response.activeTabs || 0;
      document.getElementById('stat-viewers').textContent = response.currentViewers || 0;
      document.getElementById('stat-success').textContent = response.successTabs || 0;
      document.getElementById('stat-failed').textContent = response.failedTabs || 0;
      document.getElementById('stat-target').textContent = response.targetViewers || 0;
      
      // Update progress bar
      const total = (response.successTabs || 0) + (response.failedTabs || 0);
      const successRate = total > 0 ? (response.successTabs / total) * 100 : 0;
      document.getElementById('progress-success').style.width = `${successRate}%`;
      
      // Update current mode
      document.getElementById('current-mode-display').textContent = response.currentMode || '-';
      
      // Update header status
      updateHeaderStatus(response.running);
      
      // Show target progress
      if (response.running && response.targetViewers > 0) {
        showTargetProgress(response.currentViewers || 0, response.targetViewers);
      } else {
        document.getElementById('target-progress-container').style.display = 'none';
        document.getElementById('target-progress-container2').style.display = 'none';
      }
    }
  });
}

function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}